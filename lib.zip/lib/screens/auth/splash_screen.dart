import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:foodgo/colors/app_colors.dart';
import 'package:foodgo/screens/auth/on_boarding.dart';
import 'package:foodgo/screens/home/home_page.dart';
import 'package:foodgo/service/storage_service.dart';

import '../../gen/assets.gen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  void checkLogin() async {
    final email = await StorageService.getInfo('email');
    if (email != null) {
      Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context) =>HomePage()), (_)=>false);


    }
    else{
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) =>OnBoarding()),
      );

    }
  }

bool isInternet= true;
  @override
  void initState() {
//     Connectivity().onConnectivityChanged.listen((status){
//       print(status);
//       if(status.contains(ConnectivityResult.none)){
//         showModalBottomSheet(context: context, builder: (context)=>Container(
//           height: 500,
//           width: double.infinity,
//           decoration: BoxDecoration(
//             color: AppColors.white
//           ),
//           child: Center(child: Text("Internetga ulan ddd"),),
//         ),);
//
//       }else if(status.contains(ConnectivityResult.wifi)||status.contains(ConnectivityResult.mobile)){
//         Navigator.pop(context);
//         print('internet bor aka');
//
//       }
//     });






    Timer(Duration(seconds: 3), () {
     checkLogin();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.white,
      body: Center(
        child: SizedBox(
          width: 144,
          height: 179,
          child: Image.asset(
            Assets.images.logo.path,
            fit: BoxFit.cover,

            errorBuilder: (context, error, stackTrace) {
              return Text('Rasm Yullanmadi');
            },
          ),
        ),
      ),
    );
  }
}
