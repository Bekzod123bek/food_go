import 'package:flutter/cupertino.dart';
import 'package:foodgo/colors/app_colors.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../model/food_model.dart';
import 'package:flutter/material.dart';

class DetailScreen extends StatelessWidget {
  const DetailScreen({super.key, required this.resturant});

  final Resturant resturant;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: AppColors.white.withAlpha(1),
        leadingWidth: 100,
        leading: InkWell(
          onTap: (){
            Navigator.pop(context);
          },
          child: CircleAvatar(
            backgroundColor: AppColors.white.withAlpha(150),
            child: Center(child: Icon(CupertinoIcons.left_chevron)),
          ),
        ),

      ),
      body: Column(
        children: [
          Expanded(
            child: Image.network(
              resturant.image,
              fit: BoxFit.cover,
              height: double.infinity,
              width: double.infinity,
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,

                children: [

                  Text('Deccription',style: GoogleFonts.poppins(fontSize: 42,fontWeight: FontWeight.w900),),
                  Text(resturant.description),

                  Row(
                    children: [
                      Icon(Icons.location_on),
                      Text(resturant.location),
                    ],
                  ),
                  SizedBox(
                    height: 200,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: resturant.menu.length,
                      itemBuilder: (context, index) { 
                        return  Chip(label: Text(resturant.menu[index].name));
                      },
                    ),
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
