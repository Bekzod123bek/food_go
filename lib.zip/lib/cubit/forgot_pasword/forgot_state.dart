

abstract class ForgetState {   }

class ForgetInitialState extends ForgetState {}
class ForgetErorState extends ForgetState {}
class ForgetSuccessState extends ForgetState {}